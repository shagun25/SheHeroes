import 'package:flutter/foundation.dart';

class EmergencyProvider with ChangeNotifier {
  List<double> emergencyContacts = List();
}
