import 'package:flutter/material.dart';
import 'package:hexcolor/hexcolor.dart';

Color bg = HexColor("#EFE6DD");
Gradient but = LinearGradient(
  colors: [HexColor("#ea6a88"), HexColor("#f8a9bc")],
);
Color actbut = HexColor("#5858FF");
Color head = HexColor("5858FF");
