class EmergencyStrategy {
  EmergencyStrategy(
      {this.title,
      this.videoUrl,
      this.description,
      this.imageUrl,
      this.subTitle});
  final String title;
  final String videoUrl;
  final String description;
  final String imageUrl;
  final String subTitle;
}
